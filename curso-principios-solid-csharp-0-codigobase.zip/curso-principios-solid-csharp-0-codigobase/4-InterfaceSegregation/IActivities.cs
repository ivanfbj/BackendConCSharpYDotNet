namespace InterfaceSegregation
{
    public interface IActivities
    {
        void Plan();
        void Comunicate();
        void Design();
        void Develop();
        void Test();
    }
}