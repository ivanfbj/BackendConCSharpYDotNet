# Principios SOLID en C# curso
